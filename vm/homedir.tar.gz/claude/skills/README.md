# Skills

These skills will be automatically picked up by Claude and OpenCode.
